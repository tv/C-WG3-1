void SCR_CaptureVideo_Ogg_Init();
qboolean SCR_CaptureVideo_Ogg_Available();
void SCR_CaptureVideo_Ogg_BeginVideo();
void SCR_CaptureVideo_Ogg_CloseDLL();
