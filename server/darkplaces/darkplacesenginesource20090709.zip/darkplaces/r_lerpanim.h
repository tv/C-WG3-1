
#ifndef R_LERPANIM_H
#define R_LERPANIM_H

void R_LerpAnimation(entity_render_t *r);

#endif

