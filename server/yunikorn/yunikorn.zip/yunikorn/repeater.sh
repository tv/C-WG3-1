#!/bin/sh
java -cp yunikorn.jar launch.HttpRepeater "$@"
