#!/bin/sh
java -Xmx512M -cp yunikorn.jar launch.MJPEGStreamer "$@"
